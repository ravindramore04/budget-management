<%@ page import="java.util.*,java.text.*" %>
<%@ include file="/jsp/adminpanel/header.jsp" %>
<%
DecimalFormat d = new DecimalFormat("##0.00");
HashMap hmAllo=new HashMap();
String strBudgroupId="";
hmAllo=(HashMap)request.getAttribute("Head");
if(hmAllo!=null && hmAllo.size()>0){
	strBudgroupId=(String)hmAllo.get("strBudgroupId");
}

//out.println("hmAllo"+hmAllo);

/*out.println("--------------------");
out.println(Head);*/
/*

*/

%>
<script language="JavaScript">
function navigation(code){
    document.HeadList.NAV.value = code;
    document.HeadList.action = "<%=strPath+"AllHead.do"%>"; 
    document.HeadList.submit();
}

function setAction(code,id){
    document.HeadList.id.value = id;
    switch(code){
        case 1:
            document.HeadList.action = "<%=strPath+"OpenHead.do"%>";
            break;
        case 2:
            document.HeadList.action = "<%=strPath+"PrintSingHead.do"%>";
            break;
        case 3:
            //delete done later
            document.HeadList.action = "<%=strPath+"OpenHead.do"%>";
            break;
        case 4:
            document.HeadList.action = "<%=strPath+"budgetNote.do"%>";
            break;
    }
    document.HeadList.opr.value=code;
    document.HeadList.submit();
}

</script>
<form name="HeadList" method="post" action="#">
    <input type="hidden" name="page" value="RptParam">
    <input type="hidden" name="NAV" value="">
    <input type="hidden" name="txtBGid" value="<%=strBudgroupId%>">

    <input type="hidden" name="id" value="">
    <input type="hidden" name="opr" value="">
    
    <td width="80%" valign="top" align="center">
	<table width="100%" border="0" cellspacing="1" cellpadding="1" align="center" >
      <tr bgcolor="#3333FF" class="titles"> 
        <td height="20"  colspan="5"> <div align="center"><U>BUDGET NOTE-2005-2006</U></div></td>
      </tr>
      <tr> 
        <td width="30%" ><strong> Name of Dept.</strong></td>
        <td colspan="3" ><strong>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;<strong>&nbsp;&nbsp;<%=(String)hmAllo.get("strName")%></strong></td>
      </tr>
      <tr> 
        <td width="30%"><strong>Budget Sanctioned</strong></td>
        <td width="10%"><strong>: Rs</strong></td>
        <td width="20%" align="right"><strong><%=(String)hmAllo.get("BSUM")%></strong></td>
        <td>&nbsp;</td>
      </tr>
      <tr> 
        <td width="30%"><strong>Amt. already spend</strong></td>
        <td><strong>:</strong> <strong>Rs&nbsp;&nbsp;</strong>&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td width="20%" align="right"><strong><%=Double.parseDouble((String)hmAllo.get("VSUM"))+Double.parseDouble((String)hmAllo.get("TSUM"))%>0</strong></td>
        <td>&nbsp;</td>
        <!-- <%=(String)hmAllo.get("VSUM")%>  -->
      </tr>
      <tr> 
        <td width="30%"><strong>Balance</strong></td>
        <td><strong>: Rs &nbsp;&nbsp;</strong>&nbsp;&nbsp;&nbsp;&nbsp; </td>
        <td width="20%" align="right"><strong> 
          <%
		String bal =(String)hmAllo.get("BSUM");
		String vou =(String)hmAllo.get("VSUM");
		String tds =(String)hmAllo.get("TSUM");
		if (bal!=null)
		{
			double result = Double.parseDouble(bal)-(Double.parseDouble(vou)+Double.parseDouble(tds));
			out.print(d.format(result));
		}	
		%>
		</strong></td>
        <td>&nbsp;</td>
      </tr>
      <tr> 
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td align="right">&nbsp;</td>
        <td >&nbsp;</td>
      </tr>
      <tr> 
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td align="right">&nbsp;</td>
        <td >&nbsp;</td>
      </tr>
      <tr> 
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td align="right">&nbsp;</td>
        <td ><strong>SIGN. OF HOD</strong></td>
      </tr>
      <tr> 
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td align="right">&nbsp;</td>
        <td><strong>Approved: Yes / No</strong></td>
      </tr>
      <tr> 
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td align="right">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr> 
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td align="right">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><strong>Chief Accounts &amp; Finance Officer</strong></td>
        <td>&nbsp;</td>
        <td align="right">&nbsp;</td>
        <td><strong>Executive Director/Principal</strong></td>
      </tr>
    </table>
			<p><hr>
      <input type="submit" accesskey="P" name="Print" value=" Print " onClick="setAction(2,<%=(String)hmAllo.get("HeadId")%>)">
      <input type="submit" accesskey="C" name="Close" value="Close" onClick="setAction(4,<%=(String)hmAllo.get("HeadId")%>)">
    </p>
    </td>		
</form>
<%@ include file="/jsp/include/footer.jsp" %>
