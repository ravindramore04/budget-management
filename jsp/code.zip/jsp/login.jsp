<%
	String strPath = "/budget0.1/";
%>
<html>
<head>
<title>Luscious Technologies Pvt. Ltd.</title>
<script language="JavaScript">
	function setAction(){
		with (document.login){
			if(txtuser.value.length>0){
				if(txtpassword.value.length>0){
					submit();	
				}else{
					alert("Please Enter Password");
				}
			}else{
				alert("Please Enter Login Name");
			}
		}
	}
</script>
<link href="<%=strPath+"html/ndgold.css"%>" rel="stylesheet" type="text/css">
<link href="<%=strPath+"html/css/link.css"%>" rel="stylesheet" type="text/css">
</head>
<body >
<form name="login"  method="post"  action="<%=strPath+"ValidatedLogin.do"%>">
<table width="100%" background="<%=strPath+"html/_images/login_bg.jpg" %>">
<Tr>
<td align="Center"><Strong><font face="Bookman Old Style" color="BLUE" size="3">MAEER'S</font></Strong>
</td>
<TR><td align="Center"><Strong><font face="Bookman Old Style" color="BLUE" size="3">Maharashtra Academy of Engineering, Alandi Pune </font></Strong></td></TR>
<TR><td align="Center"><Strong><font face="Bookman Old Style" color="BLUE" size="3">Annual Budget</font></Strong></Td></tr>	

<tr><td><table width="50%" border="0" cellspacing="1" cellpadding="4" align="center" >
	  	<tr> 
			<td width="26%" class="link">User Name:</td>
			<td colspan="3"><input type="text" name="txtuser" size="25" class="formfield"> </td>
	    </tr>
	 	<tr> 
			<td width="26%"  class="link">Password:</td>
			
      <td  colspan="3"><input type="password" name="txtpassword" size="25" class="formfield"></td>
	    </tr>

</table>
        <p align="center"> 
          <input type="button" name="logintype" value="Login" class="PPRSbmtBtn" onClick="setAction()">
        </p>
        <p align="center">&nbsp;</p>
<!--        <p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p> 
        <p align="center">&nbsp;</p> -->
        <p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
<table width="100%"><tbody><tr>
        <td><div align="center"></div></td>
</tr></tbody></table>
</td></tr>
</table>
</form>
</body>
</html>