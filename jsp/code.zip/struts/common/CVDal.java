package struts.common;
import javax.naming.*;
import java.sql.*;
import javax.transaction.*;
import java.util.*;
import java.io.*;

public class CVDal
{
	private static Connection conn;
	private  static Statement stmt=null;
	private ResultSet rs=null;
	private static HashMap ALLSQL;  //temporarily holds all the SQL's
	private  String finalSql = "";

        public CVDal(String str){
            try{
				sop("try for database--> " + str);
				String strData = "";
				if(str.equalsIgnoreCase("budget")){
					strData = "budget";
				}else if(str.equalsIgnoreCase("setting")){
					strData = "lcsyssetng";
				}
                sop("database--> " + strData);
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                conn = DriverManager.getConnection("jdbc:mysql://localhost/"+strData+"?user=root&password=");
                stmt = conn.createStatement();
				setALLSQL();
            }catch(Exception e)
            {
                e.printStackTrace();
            }
	}

	public  static void setALLSQL()
	{
		ALLSQL = new HashMap();
		//***************select query**************//
		ALLSQL.put("getCurrentDate", " select Current_date as Today ");
		ALLSQL.put("openOrg","select * from company");


		//Delete Head
		ALLSQL.put("DeleteHead","Delete from budgethead where HeadId='?'");
		ALLSQL.put("DeleteUser","Delete from Userlst where UId='?'");
		ALLSQL.put("VoucherDelete","Delete from Voucher where voucherId='?'");



		ALLSQL.put("checkUser","select * from userLst where strLogin LIKE '?' and strPwd LIKE '?'");
		ALLSQL.put("checkUserLogin","select * from userLst where strLogin LIKE '?'");
		ALLSQL.put("checkHead","select * from BudgetHead where strName LIKE '?'");

		ALLSQL.put("openAllUser","select * from userLst where lvl=2 order by strName ");
		ALLSQL.put("openAllUserWL","select * from userLst where lvl=2 order by strName limit ?,?");
		ALLSQL.put("openUserWithId","select * from userLst where lvl=2 AND UId='?'");

		ALLSQL.put("openHead","Select * from budgethead where HeadId='?'");
		ALLSQL.put("openAllHead","select * from BudgetHead order by strName");
		ALLSQL.put("openAmount","select * from BUDGETALLOC where  HeadId='?'");
		ALLSQL.put("openVouchse","select * from VOUCHER where  HeadId='?'");
		ALLSQL.put("openBalance","select * from HEADBAL where  HeadId='?'");
		ALLSQL.put("openAllHeadWL","select * from BudgetHead  order by strName limit ?,?");
		//ALLSQL.put("openAllHeadWL","select * from BudgetHead  order by strName");
		ALLSQL.put("openHeadWithId","select * from BudgetHead where HeadId='?'");

		ALLSQL.put("openAllHeadAllocation","select budgetHead.HeadId, sum(budgetalloc.dblAmount) as Allocate from budgetHead left join  budgetalloc on budgetHead.HeadId=budgetalloc.HeadId Group by budgetHead.HeadId order by budgetHead.strName ");
		ALLSQL.put("openHeadAllocation","select budgetHead.HeadId, sum(budgetalloc.dblAmount) as Allocate from budgetHead left join  budgetalloc on budgetHead.HeadId=budgetalloc.HeadId where budgetHead.HeadId='?' Group by budgetHead.HeadId");
		ALLSQL.put("openAllHeadExpanse","select budgetHead.HeadId, sum(voucher.dblAmount + voucher.dblTds) as exp from budgetHead left join voucher on budgetHead.HeadId=voucher.HeadId Group by budgetHead.HeadId order by budgetHead.strName ");
		ALLSQL.put("openHeadExpanse","select budgetHead.HeadId, sum(voucher.dblAmount + voucher.dblTds) as exp from budgetHead left join voucher on budgetHead.HeadId=voucher.HeadId where budgetHead.HeadId='?' Group by budgetHead.HeadId");




		ALLSQL.put("openAllVoucher","select *, voucher.dblAmount+voucher.dblTds as amt from voucher left join BudgetHead on voucher.HeadId = BudgetHead.HeadId order by voucher.dt desc");
		ALLSQL.put("openAllVoucherWL","select *, voucher.dblAmount+voucher.dblTds as amt from voucher left join BudgetHead on voucher.HeadId = BudgetHead.HeadId order by voucher.dt desc limit ?,?");
		ALLSQL.put("openVoucherWithId","select voucher.*, voucher.dblAmount+voucher.dblTds as amt,cheque.strChequeNo,BudgetHead.* from voucher left join BudgetHead on voucher.HeadId = BudgetHead.HeadId left join cheque on voucher.voucherId = cheque.voucherId where voucher.voucherId='?'");
		ALLSQL.put("openVoucherId","select * from voucher where voucherId='?'");

		ALLSQL.put("openAllHeadWithBalance","select * from budgethead left join headbal on budgethead.HeadId=headbal.HeadId order by budgethead.strName");
		ALLSQL.put("openAllHeadWithBalanceWL","select * from budgethead left join headbal on budgethead.HeadId=headbal.HeadId order by budgethead.strName limit ?,?");
		ALLSQL.put("openHeadBalanceWithId","select * from headbal where HeadId='?'");

		ALLSQL.put("openAllAllocationOfHead","select * from budgetalloc where HeadId='?'");
		ALLSQL.put("openAllAllocationOfHeadWL","select * from budgetalloc where HeadId='?' order by Dt limit ?,?");
		ALLSQL.put("openAllocationWithId","select * from budgetalloc where AllocId='?'");

		ALLSQL.put("lastID","select max(UId) as LastId from userlst" );
		ALLSQL.put("lastHeadID","select max(HeadId) as LastId from BudgetHead" );
		ALLSQL.put("lastAllocationID","select max(AllocId) as LastId from budgetalloc" );
		ALLSQL.put("lastVoucherID","select max(voucherId) as LastId from Voucher" );

		ALLSQL.put("insertUser","insert into userLst values('?','?','?','?','?','?','?','?','?')");
		ALLSQL.put("insertHead","insert into BudgetHead values('?','?','?','?','?','?','?','?')");
		ALLSQL.put("insertHeadBalance","insert into headbal values('?','?')");
		ALLSQL.put("InsertOrg","insert into company values('?','?','?','?','?',?,'?',?,'?')");
		ALLSQL.put("insertintobudgetallocation","insert into budgetalloc values('?','?','?','?','?',?,'?',?,'?')");
		ALLSQL.put("InsertintoHeadBalance","insert into headbal values('?','?')");
		ALLSQL.put("insertintoVoucher","insert into voucher values('?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?')");
		ALLSQL.put("insertintoCheque","insert into cheque values('?','?')");

		ALLSQL.put("FindFromVoucher","Select * From voucher where voucherId='?'");
		//ALLSQL.put("UpdateHead","Update Headbal set dblBalance=dblBalance+'?' where HeadId='?'");
		ALLSQL.put("DeleteFromVoucher","Delete From voucher where voucherId='?'");
		ALLSQL.put("DeleteFromCheque","Delete From cheque Where voucherId='?'");


		ALLSQL.put("updateUser","Update userLst set strName='?',strLogin='?', strUptdBy='?',strUptdOn='?' where UId='?'");
		ALLSQL.put("updateHead","Update BudgetHead set strName='?',strRemark='?', strUptdBy='?',strUptdOn='?' where HeadId='?'");
		ALLSQL.put("UpdateOrg","Update company set strName='?', strShortNm ='?', strAddr='?',strPh1='?', strPh2='?', strUptdBy='?', strUptdOn='?'");
		ALLSQL.put("updateintobudgetallocation","Update budgetalloc set HeadId='?', Dt ='?', dblAmount='?',strRemark='?', strInsBy='?',strInsOn='?', strUptdBy='?', strUptdOn='?' where AllocId='?'");
		ALLSQL.put("updateHeadBalance","Update headbal set dblBalance=dblBalance+'?' where HeadId='?'");
		ALLSQL.put("minusHeadBalance","Update headbal set dblBalance=dblBalance-'?' where HeadId='?'");

// Voucher Update
		ALLSQL.put("updateintoVoucher","update voucher set voucherNo='?', dt='?',HeadId='?', dblAmount ='?',dblTds ='?',strType='?',strToAcc='?',bMode ='?',strBank ='?',strReceiverNm='?',strInsBy ='?', strInsOn='?', strUptdBy ='?', strUptdOn  ='?' , strTDS='?' where voucherId='?'");


		ALLSQL.put("updateintoCheque","Update cheque set strChequeNo='?' where voucherId='?'");

		ALLSQL.put("checkPassword","select * from userLst where UId='?' and strPwd='?'");
		ALLSQL.put("saveNewPassword","Update userLst set strPwd='?' where UId='?'");

		ALLSQL.put("deleteFromAllocation","delete from budgetalloc where AllocId='?'");
//		ALLSQL.put("ViewAllAlloc","select budgethead.strName, budgethead.HeadId, budgethead.strAccNo, sum(budgetalloc.dblAmount) as BSUM from budgethead,budgetalloc where budgethead.HeadId=budgetalloc.HeadId group by budgethead.HeadId order by budgethead.HeadId where budgethead.HeadId='?'");
//		ALLSQL.put("ViewAllVouch","select budgethead.HeadId, sum(voucher.dblAmount) as VSUM from budgethead,voucher where budgethead.HeadId=voucher.HeadId and  voucher.Dt between '?' and '?' group by budgethead.HeadId order by budgethead.HeadId where budgethead.HeadId='?'");

		//ALLSQL.put("ViewAllAlloc","select budgethead.strName, budgethead.HeadId, budgethead.strAccNo,sum(budgetalloc.dblAmount) as BSUM from budgethead left join budgetalloc on budgethead.HeadId=budgetalloc.HeadId group by budgethead.HeadId order by budgethead.HeadId");
		//*************************
		ALLSQL.put("ViewAllAlloc","select budgethead.strName, budgethead.HeadId, budgethead.strAccNo,sum(budgetalloc.dblAmount) as BSUM from budgethead left join budgetalloc on budgethead.HeadId=budgetalloc.HeadId group by budgethead.HeadId order by budgethead.strName");
		//*************************
		//ALLSQL.put("ViewAllVouch","select budgethead.HeadId, sum(voucher.dblAmount) as VSUM ,sum(voucher.dblTds) as tds from budgethead left join voucher on budgethead.HeadId=voucher.HeadId where voucher.Dt between '?' and '?' group by budgethead.HeadId order by budgethead.HeadId");
		//*************************
		ALLSQL.put("ViewAllVouch","select budgethead.HeadId, sum(voucher.dblAmount) as VSUM ,sum(voucher.dblTds) as tds from budgethead left join voucher on budgethead.HeadId=voucher.HeadId where voucher.Dt between '?' and '?' group by budgethead.HeadId order by budgethead.strName");
		//*************************

		ALLSQL.put("ViewVouchWithoutDateForHeadId","select budgethead.HeadId, sum(voucher.dblAmount) as VSUM, sum(voucher.dblTds) as TSUM from budgethead left join voucher on budgethead.HeadId=voucher.HeadId where  budgethead.HeadId ='?' group by budgethead.HeadId order by budgethead.HeadId");
		ALLSQL.put("ViewAllocForHeadId","select budgethead.strName, budgethead.HeadId, budgethead.strAccNo,sum(budgetalloc.dblAmount) as BSUM from budgethead left join budgetalloc on budgethead.HeadId=budgetalloc.HeadId where  budgethead.HeadId ='?' group by budgethead.HeadId order by budgethead.HeadId");

		ALLSQL.put("acode","select count(strAccNo) as code from budgethead");



		ALLSQL.put("A_Amount","Select Sum(budgetalloc.dblAmount) as BSUM from budgetalloc where HeadId='?'");
		ALLSQL.put("V_Amount","Select Sum(voucher.dblAmount) as VSUM from voucher where HeadId='?'");
	}


	public  void setCustomSQL(String sql){
		finalSql = sql;
	}

	public  void setSQL(String sql,Vector vec)
	{
		sop("sql--"+sql+"--");
		sop("vec--"+vec+"--");

		finalSql = "";

		String strTemp = (String)ALLSQL.get(sql);


		int paramIndex = 0;
        	System.out.println("strTemp is------"+strTemp);

		for(int i=0;i<strTemp.length();i++)
		{
			if(strTemp.charAt(i)== '?')
			{

//				sop("inside if of setsql()------");

				finalSql = finalSql + (String)vec.elementAt(paramIndex);
//				sop("finalsql------"+finalSql);
				paramIndex++;
			}
			else
			{

				finalSql = finalSql + strTemp.charAt(i);
//				sop("inside else of setsql()------"+finalSql);

			}
		}
	sop("\n\nfinalSql--"+finalSql+"--\n\n");
	}



	public Collection executeQuery()
	{
			//sop("inside executeQuery---");
			try
			{
				Vector vec = new Vector();
				ResultSet rs = stmt.executeQuery(finalSql);

				ResultSetMetaData md = rs.getMetaData();


					int cc = md.getColumnCount();
					while (rs.next())
					{
						HashMap hm = new HashMap();
						for(int i=0;i<cc;i++)
						{
							int ii = i+1;

							String strData = rs.getString(ii);
							String strColumn = md.getColumnName(ii);
							hm.put(strColumn, strData);
						}

						vec.add(hm);

					}
				return vec;


			} catch(Exception e)
			{
				sop("Failed while Executing Query");
				e.printStackTrace();
			}
			return null;
		}


	public int executeUpdate()
	{
		int u=0 ;
		try
		{
			Vector vec = new Vector();
			u = stmt.executeUpdate(finalSql);

		}
		catch(Exception e)
		{
			sop("Failed while Executing update");
			e.printStackTrace();
		}
		return u;

	}

	public void sop(String msg)
	{
            System.out.println(msg);
        }
}
