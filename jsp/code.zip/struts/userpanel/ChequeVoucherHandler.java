package struts.userpanel;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.action.DynaActionForm;

import javax.servlet.*;
import javax.servlet.http.*;

import java.util.HashMap;
import struts.common.CVDal;
import struts.common.CommonLogic;
import struts.common.ErrorHandler;
import java.util.*;
import java.sql.*;

public class ChequeVoucherHandler extends org.apache.struts.action.Action
{
    private static final String Success = "success";
    public static final String GLOBAL_FORWARD_failure = "failure";
    private static String FORWARD_final = GLOBAL_FORWARD_failure;

    public ActionForward execute(ActionMapping mapping, ActionForm form,HttpServletRequest request,
	HttpServletResponse response) throws RuntimeException,Exception
	{
            HttpSession session = request.getSession(true);
            ErrorHandler eh = new ErrorHandler();
            try{
                CommonLogic cl = new CommonLogic();
                CVDal cvdal = new CVDal("budget");
                HashMap hmLocation = new HashMap();
                HashMap hmFinal = new HashMap();
                Vector vec = new Vector();

				vec.clear();
				cvdal.setSQL("openAllHead", vec);
				Vector vec1 = (Vector)cvdal.executeQuery();
				sop("------------------------------------->>>>>>>>>");
				sop("------------------------------------->>>>>>>>>");
				sop("------------------------------------->>>>>>>>>");

				sop(""+vec1);

				sop("------------------------------------->>>>>>>>>");
				sop("------------------------------------->>>>>>>>>");
				sop("------------------------------------->>>>>>>>>");
				sop("------------------------------------->>>>>>>>>");

				HashMap hmAll = new HashMap();
				if(vec1!=null && vec1.size()>0){
					for(int indx=0;indx<vec1.size();indx++){
						HashMap hmt = (HashMap)vec1.elementAt(indx);
						String strTempId = (String)hmt.get("HeadId");
						vec.clear();
						vec.addElement(strTempId);
						cvdal.setSQL("openHeadAllocation",vec);
						Vector vec2 = (Vector)cvdal.executeQuery();
						if(vec2!=null && vec2.size()>0)
						{
							HashMap hmmt = (HashMap)vec2.elementAt(0);
							hmt.put("allocate",(String)hmmt.get("Allocate"));
						}
						cvdal.setSQL("openHeadExpanse", vec);
						vec2 = (Vector)cvdal.executeQuery();
						if(vec2!=null && vec2.size()>0)
						{
							HashMap hmmt = (HashMap)vec2.elementAt(0);
							hmt.put("exp",(String)hmmt.get("exp"));
						}
						hmAll.put(""+indx, hmt);
					}
				}
				request.setAttribute("all", hmAll);

                DynaActionForm daf = (DynaActionForm)form;
                String strId = (String)daf.get("id");
                //int nOpr = Integer.parseInt((String)daf.get("opr"));
                int nOpr=2;
                switch(nOpr){
                    case 1:
                        //add new
                    case 2:
                        //update
                        vec.clear();
                        vec.addElement(strId);
                        cvdal.setSQL("openVoucherWithId", vec);
                        vec1 = (Vector)cvdal.executeQuery();
                        if(vec1!=null && vec1.size()>0){
                            hmFinal = (HashMap)vec1.elementAt(0);
                        }
                    case 3:
                        //delete
                }

                request.setAttribute("data", hmFinal);
                FORWARD_final = Success;
            }catch(Exception e){
                e.printStackTrace();
                String err = eh.getError("147420");
				String nxtpg = "ValidateLogin.do";
				HashMap hmErr = new HashMap();
				hmErr.put("no","147420");
				hmErr.put("Source","DeleteVoucherHandler");
				hmErr.put("err",err);
				hmErr.put("nxtpg",nxtpg);
				request.setAttribute("err",hmErr);
				request.setAttribute("eDetail",e);
                FORWARD_final = GLOBAL_FORWARD_failure;
            }

            return (mapping.findForward(FORWARD_final));
	}//End of execute()

	public void sop(String msg){
		System.out.println(msg);
	}
}