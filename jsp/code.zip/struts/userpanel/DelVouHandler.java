package struts.userpanel;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.action.DynaActionForm;

import javax.servlet.*;
import javax.servlet.http.*;

import java.util.HashMap;
import struts.common.CVDal;
import struts.common.CommonLogic;
import struts.common.ErrorHandler;
import java.util.*;
import java.sql.*;

public class DelVouHandler extends org.apache.struts.action.Action
{
	private static final String Success = "success";
	public static final String GLOBAL_FORWARD_failure = "failure";
	private static String FORWARD_final = GLOBAL_FORWARD_failure;

    public ActionForward execute(ActionMapping mapping, ActionForm form,HttpServletRequest request,
	HttpServletResponse response) throws RuntimeException,Exception
	{
			ErrorHandler eh = new ErrorHandler();
		try{

			CommonLogic cl = new CommonLogic();
			CVDal cvdal = new CVDal("budget");
            HttpSession session = request.getSession(true);
			HashMap hmUser = (HashMap)session.getAttribute("user");
			String strUserId = (String)hmUser.get("UId");
			String strToday = (String)cl.getToday();
			Vector vec=new Vector();

			DynaActionForm daf = (DynaActionForm)form;

            String strId= (String)daf.get("txtId");
			vec.addElement(strId);

			cvdal.setSQL("FindFromVoucher",vec);
			Vector vec1 = (Vector)cvdal.executeQuery();
			HashMap hmt = new HashMap();
			if(vec1!=null && vec1.size()>0)
			{
					hmt = (HashMap)vec1.elementAt(0);
			}
/*			sop("----------------------------");
			sop("----------------------------");
			sop("HashMap Size -->"+hmt.size());
			sop("Voucher Id --> "+strId);
			sop("----------------------------");
			sop((String)hmt.get("voucherId"));
			sop((String)hmt.get("HeadId"));
			sop((String)hmt.get("dblAmount"));
			sop((String)hmt.get("dblTds"));
*/
			String Amount =(String)hmt.get("dblAmount");
			String TDS = (String)hmt.get("dblTds");
			double Tot =Double.parseDouble(Amount)+Double.parseDouble(TDS);
/*			sop("Total-->"+Tot);
			sop("----------------------------");
			sop("----------------------------");
*/
			vec.clear();
			vec.addElement(""+Tot);
			vec.addElement((String)hmt.get("HeadId"));
			cvdal.setSQL("updateHeadBalance",vec);
			int irow0=cvdal.executeUpdate();

			vec.clear();
			vec.addElement(strId);
			cvdal.setSQL("DeleteFromVoucher",vec);
			int irow=cvdal.executeUpdate();
			cvdal.setSQL("DeleteFromCheque",vec);
			int irow1=cvdal.executeUpdate();


			FORWARD_final = Success;
		}catch(Exception e){
			e.printStackTrace();
			String err = eh.getError("138530");
			String nxtpg = "CnlVoucher.do";
			HashMap hmErr = new HashMap();
			hmErr.put("no","138530");
			hmErr.put("Source","DelVouHandler");
			hmErr.put("err",err);
			hmErr.put("nxtpg",nxtpg);
			request.setAttribute("err",hmErr);
			request.setAttribute("eDetail",e);
			FORWARD_final = GLOBAL_FORWARD_failure;
		}
		return (mapping.findForward(FORWARD_final));
	}//End of execute()
	public void sop(String msg){
		System.out.println(msg);
	}
}
